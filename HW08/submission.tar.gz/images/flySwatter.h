/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 flySwatter flySwatter.png 
 * Time-stamp: Thursday 03/26/2020, 16:51:21
 * 
 * Image Information
 * -----------------
 * flySwatter.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FLYSWATTER_H
#define FLYSWATTER_H

extern const unsigned short flySwatter[38400];
#define FLYSWATTER_SIZE 76800
#define FLYSWATTER_LENGTH 38400
#define FLYSWATTER_WIDTH 240
#define FLYSWATTER_HEIGHT 160

#endif

