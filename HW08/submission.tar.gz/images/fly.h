/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=10x10 fly fly.png 
 * Time-stamp: Wednesday 03/25/2020, 04:25:18
 * 
 * Image Information
 * -----------------
 * fly.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FLY_H
#define FLY_H

extern const unsigned short fly[100];
#define FLY_SIZE 200
#define FLY_LENGTH 100
#define FLY_WIDTH 10
#define FLY_HEIGHT 10

#endif

