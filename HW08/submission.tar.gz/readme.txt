This is a fly swatter game by Anand Krishnan. In the game state, the user controls a fly swatter that starts in the bottom-center of the screen. 
At the same time, there are 4 flies moving around the screen and they must be swatted using the fly swatter tool. The user can control 
the fly swatter using the up, down, left, and right arrowkeys to move it around the screen. The user can click select (backspace) at 
any time during the program to restart the game state and go back to the title screen. The user clicks the start button (enter) on
the title screen to go to the game. Lastly, the user clicks X in the game state if they want to finish playing the game and go to 
game ending screen. 